This directory contains an ArcGIS toolbox and associated scripts 
for creating, manipulating, and validating NCGMP09-style geologic 
map databases. See the Docs folder for more information. 

For more information on the NCGMP09 database schema, see
http://ngmdb.usgs.gov/Info/standards/NCGMP09/


To install this toolbox, either

1) unzip (if necessary) and place the folder NCGMPToolbox in
a locale of your choice.  Start ArcCatalog or ArcMap, open 
the Arc Toolbox window, right click on empty space in the Arc 
Toolbox window, and select "Add Toolbox".  Then navigate to 
the NCGMPToolbox folder and select the file 
NCGMP09v1.1_Toolbox3b_Arc10.1.tbx. 

Right-click again on empty space in the Arc Toolbox window and
select "Save settings" and then "Default" to have the NCGMP09
toolbox available next time you open ArcCatalog or ArcMap.

or, 

2) place the CONTENTS of the folder in your Documents and Settings 
folder, within 
C:\Documents and Settings\<user>\Application Data\ESRI\Desktop10.0\ArcToolbox\My Toolboxes
(this is the pathname in Windows XP; it may differ with other operating
systems). Then, in ArcCatalog, scroll to the bottom of the left-hand 
"Catalog Tree" pane, open Toolboxes/My Toolboxes, and the new 
toolbox should be present.

See the Docs subdirectory of this package for documentation in 
.doc and .pdf format. 

----

Significant changes from version 1 of this toolbox are:

* Improved "Create New Database" script. Has option to enable editor 
tracking. Correctly adds cartographic representations to a new database, 
using the AZGS subset/superset of the FGDC geologic map symbols.  
Thanks to Janel Day (AZGS) for demonstrating how to do this!

* New "Set Symbol Values" script. Calculates values of Symbol field based 
on Type, LocationConfidenceMeters, ExistenceConfidence, IdentyConfidence, 
and map scale. 

* New "Topology Check" script. Examines a nearly-complete geodatabase and
finds common topological errors. Checks for line and polygon topology, node 
topology, fault directions, map-unit adjacency, duplicate point features, 
and short lines, small polys, and sliver polys

* "Project Map Data to Cross Section" now uses existing Z values for point 
data (if present), rather than extracting Z from the DEM. This facilitates
projection of lidar point cloud data. 


Known issues with these scripts include:

* "Project Map Data to Cross Section" doesn't always produce the correct 
apparent dip direction. The dip magnitude is correct, but it may be in the
wrong direction.

* "MapOutline" stumbles over some choices of datum.

* "FGDC CSDGM2 Metadata" fails when run from within ArcGIS. However, it 
works if invoked from the DOS command line.

* .docx to DMU and DMU to .docx require the lxml Python module, which 
some find difficult to install. The other scripts run without lxml. 


----

Ralph Haugerud
rhaugerud@usgs.gov

Evan Thoms
ethoms@usgs.gov

16 September 2013